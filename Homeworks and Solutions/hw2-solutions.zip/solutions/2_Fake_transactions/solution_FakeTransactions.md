Fake Transactions
=================

## Determining the fields of the records

The encrypted records can be segmented based on the field sizes known from the format:

	dc75d21c ae 71a1fbba62ec 52 ee48ac8f667e ea 75941d3b78f2bc
	dc75d218 ae 73a7fdb464e0 52 e848ac816673 ea 75941d3a7df7bc
	dc75d11e ae 72a4f6b465ef 52 e94aa9836572 ea 75941d3b79f4bc


## Some immediate observations

We can make some immediate observations:
- All encrypted transaction numbers have the same 2 leading bytes (`dc 75`). We suspect that transaction numbers are small and they probably start with 2 leading 0s (00).
- Similarly, all encrypted amounts start with the same 3 leading bytes (`75 94 1d`). We suspect that amounts  are small and these are leading 0's.
- No repeating IDs appear in the same role (all source account IDs are different and all destination account IDs are different, too).


## Figuring out the destination IDs

Since all records are encrypted with the same key stream, we can XOR the same field from different records: the key stream bytes will cancel out and we obtain the XOR sum of the plaintext fields ((F + K) + (F’ + K) = F + F’). We may use this to figure out the destination account IDs in each record:

Let’s compute first the XOR sum of the known account IDs (results are shown in hex format):
- ’A74635’ + ’B29846’ = `3050d0e0703`
- ’A74635’ + ’C12859’ = `206060e060c`
- ’A74635’ + ’D37465’ = `50403020500`
- ’A74635’ + ’E12654’ = `40606000601`
- ’B29846’ + ’C12859’ = `1030b00010f`
- ’B29846’ + ’D37465’ = `6010e0c0203`
- ’B29846’ + ’E12654’ = `7030b0e0102`
- ’C12859’ + ’D37465’ = `702050c030c`
- ’C12859’ + ’E12654’ = `600000e000d`
- ’D37465’ + ’E12654’ = `10205020301`

Now let’s XOR the destination IDs in record 1 and 2:

	ee48ac8f667e + e848ac816673 = 600000e000d

This matches ’C12859’ + ’E12654’, so `ee48ac8f667e` is the encryption of ’C12859’ and `e848ac816673` is the encryption of ’E12654’, or vice versa.

Now let’s XOR the destination IDs in record 1 and 3:

	ee48ac8f667e + e94aa9836572 = 702050c030c 

This matches ’C12859’ + ’D37465’, so  `ee48ac8f667e` is the encryption of ’C12859’ and `e94aa9836572` is the encryption of ’D37465’, or vice versa.

From this, it follows that 
- `ee48ac8f667e` must be the encryption of ’C12859’
- `e848ac816673` must be the encryption of ’E12654’
- `e94aa9836572` must be the encryption of ’D37465’


## Modifying the destination ID in the 2nd record

Let’s modify for instance the 2nd record. We’ve just obtained that the  destination account ID in this record is ’E12654’. We need to XOR to this field ’E12654’+’X1337X’ (= `1d000105026c` in hex) in order to replace the ID with ’X1337X’.  

## Modifying the transaction number and the amount in the 2nd record

We need to XOR the result of ’0’ + ’1’ (= `01` in hex) to the second byte of the transaction number to change it from ’0’ to ’1’. 
And, we XOR the result of ’000’ + ’999’ (= `090909` in hex) to the leading 3 bytes of the amount to change it to a larger sum.


## Example for a fake transaction

In summary:

	..01.... .. ............ .. 1d000105026c .. 090909........
	XOR 
	dc75d218 ae 73a7fdb464e0 52 e848ac816673 ea 75941d3a7df7bc
	= 
	dc74d218 ae 73a7fdb464e0 52 f548ad84641f ea 7c9d143a7df7bc

So the fake encrypted transaction record will be:

	dc74d218ae73a7fdb464e052f548ad84641fea7c9d143a7df7bc

To verify, we reveal that the key stream we used was:

	ec45e32cd23096cf8c51d92ead799eb753479645a42d0b4fc78c

