A message from the Oracle
=========================

We captured a Greek man, Your Majesty, who had this garbled message scratched on his waist-belt:

Fwa  L oatwnakry aoci eastenydnt dgo deta uS dhef pg amrialbtoonroy nmhtr t  aaiPhmHb oeeueiEurnsrtiss taat it cnhcahmlteineoesrt  us  ymbr oy eonlfomnu i uu nanwrsOd ei tr d dg  oe erbifa  eef d 

Only Your Greatness, the earthly deputy of the Supreme God, Ahura Mazda, has the wisdom to solve this puzzle!