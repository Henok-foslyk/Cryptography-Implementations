A message from the Oracle
=========================

Ahura Mazda is the creator and sole God of Zoroastrianism, the old Mede and Persian religion, which spread across Asia predating Christianity. The oracle may refer to the Oracle at Delphi. So the message may be a Spartan message intercepted by the men of Xerxes, and it may be encrypted with the Scytale. 

The Scytale is a transposition cipher, which mixes the letters of the plaintext message. The ciphertext can be decrypted by finding the period length L such that rearranging the letters by taking every L-th letter results in a meaningful text.

