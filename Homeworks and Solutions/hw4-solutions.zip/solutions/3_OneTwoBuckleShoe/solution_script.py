import array

ifile1 = open("LabProfile-v1.crypt", "rb")
ifile2 = open("LabProfile-v1.1.crypt", "rb")
ofile = open("LabProfile-recovered.txt", "wb")

# skip 128 + 16 = 144 bytes (8 + 1 blocks) from beginning
data1 = ifile1.read(144)
data2 = ifile2.read(144)

m = array.array('B', b'CrySyS Lab, Buda')

# read next block from both files, XOR them, and XOR in the previously discovered plaintext block stored in m
eof = False
while (not eof):
    data1 = array.array('B', ifile1.read(16))
    data2 = array.array('B', ifile2.read(16))
    if len(data2) < 16:
        eof = True
    else:		
        for i in range(len(data1)):
            m[i] = data1[i]^data2[i]^m[i]
        ofile.write(m)

ifile1.close()
ifile2.close()
ofile.close()
