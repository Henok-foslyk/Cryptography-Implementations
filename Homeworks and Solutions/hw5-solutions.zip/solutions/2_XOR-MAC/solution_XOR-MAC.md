XOR-MAC
=======

The MAC function used by the bank is weak. We can change bits in the same position in even number of blocks, and the XOR sum of the blocks will remain the same. In other words, if we have a valid transaction with a valid MAC, that MAC value will be valid also for a new transaction that we obtain by making the same changes in even number of blocks (e.g., 2) of the original transaction. The question is if we can make those changes to the original transaction such that we get a higher transaction number, later transaction time, larger sum, and a still correct format.

Here’s again the transaction we have (with position numbers printed above):

0123456789abcdef0123456789abcdef0123456789abcdef
2020:02:23|11:23:38|21450|A74635|B29846|00002500

# Increasing the amount and the transaction number

Fortunately, the first digit 0 in the amount and the last digit 0 of the transaction number happen to be in the same position within the 16-byte block (both are in position 8), so we can change them in an identical way. For instance, the new transaction record could be:

0123456789abcdef0123456789abcdef0123456789abcdef
2020:02:23|11:23:38|21459|A74635|B29846|90002500
                        ^               ^

# Increasing the time

We can also notice that the minute value is at position ef in the block, and the last two digits of the amount are also in those positions. But now, they have different values so we must be careful with changing them. 

Let's consider the first digit of the minute (in position e):
    '2' is hex x32, which is binary b00110010 
The last but first digit of the sum (also in position e):
    '0' is hex x30, which is binary b00110000
So we can change, for instance, their last bit:
    b00110010 --> b00110011 = x33 = '3'
    b00110000 --> b00110001 = x31 = '1' 

This results in the following transaction (note that the sum became even larger):

2020:02:23|11:33:38|21459|A74635|B29846|90002510

In this transaction, the time, the transaction number, and the amount are larger than in the original transaction, while it is still well formatted, and the MAC of the original transaction should be valid for this one too. Let's save this transaction into a file t-fake.txt, and check if this would be accepted by the bank by running the MAC verification script we provided in the handout folder:

python3 xormac-ver.py -k 'a7GH81h39pyX26ls' -i t-fake.txt -m t-mac.bin
Verification succeeded: valid MAC.
