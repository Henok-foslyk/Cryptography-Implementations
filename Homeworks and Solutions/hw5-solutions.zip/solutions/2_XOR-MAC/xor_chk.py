from Crypto.Util.strxor import strxor


msg1 = b'2020:02:23|11:23:38|21450|A74635|B29846|00002500'
msg2 = b'.......PUT YOUR FAKE TRANSACTION HERE...........' 

# compute checksum
def xor_checksum(msg):
	chksum = b'\x00'*16
	for i in range(len(msg)//16):
	    chksum = strxor(chksum, msg[i*16:(i+1)*16])
	return chksum

print(xor_checksum(msg1) == xor_checksum(msg2))

