Filling the gap
===============

This is what we know:

                  X_i
                   |
             +-----+
             |     |
             |     |
        T_i ----->(+)--->[ MD5 ]---+---> output_i = K
             |                     |
             |                     |
             +--->(+)<-------------+
                   |
                   | X_(i+1)
                   |
             +-----+
             |     |
             |     |
    T_(i+1) ----->(+)--->[ MD5 ]---+---> output_(i+1) = IV
             |                     |
             |                     |
             +--->(+)<-------------+
                   |
                   |
                  X_(i+2)

where X_i and X_i+2 are given, and IV can be obtained from the encrypted file (first 16 bytes):

    X_i     =  b5562ff25e66e602eae4dbd61b2d5e8b
    X_(i+2) =  9d6f86e273de3f3905bc068defea0571
    IV      =  9ad88a6a6d36de15c14bdb9c19e5e91d

We can compute 

    X_(i+1) = IV + X_(i+2), and  
    K = X_(i+1) + X_i = IV + X_(i+2) + X_i = b2e1237a408e072e2e1306c7ed22b2e7

We can then use K and the provided CBC decoding script to decrypt the file. 
