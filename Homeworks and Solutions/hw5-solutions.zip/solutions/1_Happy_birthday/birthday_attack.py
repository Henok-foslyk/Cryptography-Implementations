from Crypto.Hash import MD5

n = 16

TEMPLATE1  = "Dear Mr_0_Jones_1_"
TEMPLATE1 += "I_2_m delighted to inform you_3_that you_4_ve been selected as_5_"
TEMPLATE1 += "one of _6_ winners of _7_ competion._8_Your prize will be "
TEMPLATE1 += "1_9_ _a_, _b_ we will transfer to your bank account_c_"
TEMPLATE1 += "within _d_ week. "
TEMPLATE1 += "Best regards, "
TEMPLATE1 += "A_e__f_Clark"

SUBS1 = [[".", ". ", "_0_"],
		 [", ", "! ", "_1_"],
		 ["'", " a", "_2_"],
		 [" ", ", ", "_3_"],
		 ["'", " ha", "_4_"],
		 [" ", "  ", "_5_"],
		 ["the", "our", "_6_"],
		 ["the", "our", "_7_"],
		 [" ", "  ", "_8_"],
		 [",000,000", " million", "_9_"],
		 ["USD", "$", "_a_"],
		 ["which", "that", "_b_"],
		 [" ", ", ", "_c_"],
		 ["one", "1", "_d_"],
		 [".", "ndrew", "_e_"],
		 [" B. ", " ", "_f_"]]

TEMPLATE2  = "Dear Mr_0_Jones_1_"
TEMPLATE2 += "I regret to inform you_2_that your complaint was_3_ approved_4_"
TEMPLATE2 += "by _5_ management. This_6_unfortunately means that you can_7_ "
TEMPLATE2 += "reclaim your cost of 1_8_234 _9__a_and in addition_b_you have "
TEMPLATE2 += "to cover our investigation cost of 345 _c_ _d_. "
TEMPLATE2 += "Yours sincerely_e_"
TEMPLATE2 += "A_f_ B. Clark"

SUBS2 = [[".", ". ", "_0_"],
		 [", ", "! ", "_1_"],
		 [" ", ", ", "_2_"],
		 [" not", "n't", "_3_"],
		 [" ", "  ", "_4_"],
		 ["our", "the", "_5_"],
		 [" ", ", ", "_6_"],
		 ["not", "'t", "_7_"],
		 [" ", ",", "_8_"],
		 ["USD", "$", "_9_"],
		 [", ", " ", "_a_"],
		 [", ", " ", "_b_"],
		 ["USD", "$", "_c_"],
		 ["as well", "too", "_d_"],
		 [", ", ",  ", "_e_"],
		 ["ndrew", ".", "_f_"]]


def trhash(x):
	h = MD5.new()
	h.update(x)
	return h.digest()[0:4]

def get_variant(template, subs, index):
	text = template
	for i in range(n):
		b, index = index%2, index//2
		text = text.replace(subs[i][2], subs[i][b])
	return(text)

H = []
for i in range(2**n):
	print(i, end='\r')
	t = get_variant(TEMPLATE1, SUBS1, i)
	h = trhash(t.encode('ascii'))
	H.append(h)
print('Half-way done.')

for i in range(2**n):
	print(i, end='\r')
	t = get_variant(TEMPLATE2, SUBS2, i)
	h = trhash(t.encode('ascii'))
	if h in H:
		j = H.index(h)
		s = get_variant(TEMPLATE1, SUBS1, j)
		g = trhash(s.encode('ascii'))
		print(t)
		print(h.hex())
		print(s)
		print(g.hex())
		break
print('All done.')


