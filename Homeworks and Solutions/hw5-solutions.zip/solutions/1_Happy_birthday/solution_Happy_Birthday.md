Happy Birthday
==============

Notice that the hash function trhash() produces 4-byte (32-bit) outputs. This is rather small as hash length, and we may be able to mount a birthday attack of complexity sqrt(2^32) = 2^16, which looks quite feasible in practice.

We use the following variant of the Birthday Paradox: Let's assume we have a set S of size N. We randomly choose a subset S1 of size N1 from S and record the chosen elements. Then we put back the chosen elements in S, and we choose again randomly a subset S2 of size N2 from S. It is known that the probability that S1 and S2 have at least one common element (i.e., they have a non-empty intersection) is larger than 1/2 when N1 and N2 are both around sqrt(N).

The idea is then to produce 2^16 variants of the given first message, and compute and store the trhash values of those variants (this will be the first subset of all possible trhash values). Then we produce 2^16 variants of the given second message, compute the trhash values of those variants (this will be the second subset), and check if any of these hash values occurs in the stored hashes of the first message variants. If a match is found (which should happen with probabilty larger than 1/2), then we found two variants that have the same trhash value.

The question is, how to produce 2^16 semantically equivalent variants of the given messages. For that, we can find 16 places within a given message where we can use one of two possible options with equivalent meaning, like "I'm delighted" and "I am delighted" or "to inform you" or "to inform  you" (notice the two spaces between "inform" and "you" in the latter variant), and produce all possible 2^16 variants by choosing either one or the other option in each of the 16 places. 

A possible solution is given below:

```python script birthday_attack.py

from Crypto.Hash import MD5

n = 16

TEMPLATE1  = "Dear Mr_0_Jones_1_"
TEMPLATE1 += "I_2_m delighted to inform you_3_that you_4_ve been selected as_5_"
TEMPLATE1 += "one of _6_ winners of _7_ competion._8_Your prize will be "
TEMPLATE1 += "1_9_ _a_, _b_ we will transfer to your bank account_c_"
TEMPLATE1 += "within _d_ week. "
TEMPLATE1 += "Best regards, "
TEMPLATE1 += "A_e__f_Clark"

SUBS1 = [[".", ". ", "_0_"],
		 [", ", "! ", "_1_"],
		 ["'", " a", "_2_"],
		 [" ", ", ", "_3_"],
		 ["'", " ha", "_4_"],
		 [" ", "  ", "_5_"],
		 ["the", "our", "_6_"],
		 ["the", "our", "_7_"],
		 [" ", "  ", "_8_"],
		 [",000,000", " million", "_9_"],
		 ["USD", "$", "_a_"],
		 ["which", "that", "_b_"],
		 [" ", ", ", "_c_"],
		 ["one", "1", "_d_"],
		 [".", "ndrew", "_e_"],
		 [" B. ", " ", "_f_"]]

TEMPLATE2  = "Dear Mr_0_Jones_1_"
TEMPLATE2 += "I regret to inform you_2_that your complaint was_3_ approved_4_"
TEMPLATE2 += "by _5_ management. This_6_unfortunately means that you can_7_ "
TEMPLATE2 += "reclaim your cost of 1_8_234 _9__a_and in addition_b_you have "
TEMPLATE2 += "to cover our investigation cost of 345 _c_ _d_. "
TEMPLATE2 += "Yours sincerely_e_"
TEMPLATE2 += "A_f_ B. Clark"

SUBS2 = [[".", ". ", "_0_"],
		 [", ", "! ", "_1_"],
		 [" ", ", ", "_2_"],
		 [" not", "n't", "_3_"],
		 [" ", "  ", "_4_"],
		 ["our", "the", "_5_"],
		 [" ", ", ", "_6_"],
		 ["not", "'t", "_7_"],
		 [" ", ",", "_8_"],
		 ["USD", "$", "_9_"],
		 [", ", " ", "_a_"],
		 [", ", " ", "_b_"],
		 ["USD", "$", "_c_"],
		 ["as well", "too", "_d_"],
		 [", ", ",  ", "_e_"],
		 ["ndrew", ".", "_f_"]]


def trhash(x):
	h = MD5.new()
	h.update(x)
	return h.digest()[0:4]

def get_variant(template, subs, index):
	text = template
	for i in range(n):
		b, index = index%2, index//2
		text = text.replace(subs[i][2], subs[i][b])
	return(text)

H = []
for i in range(2**n):
	print(i, end='\r')
	t = get_variant(TEMPLATE1, SUBS1, i)
	h = trhash(t.encode('ascii'))
	H.append(h)
print('Half-way done.')

for i in range(2**n):
	print(i, end='\r')
	t = get_variant(TEMPLATE2, SUBS2, i)
	h = trhash(t.encode('ascii'))
	if h in H:
		j = H.index(h)
		s = get_variant(TEMPLATE1, SUBS1, j)
		g = trhash(s.encode('ascii'))
		print(t)
		print(h.hex())
		print(s)
		print(g.hex())
		break
print('All done.')
```

As one can see, we marked with "_i_" (i = 0, 1, ..., 9, a, ..., f) the 16 places in the messages where we have two semantically equivalent options, and those options are stored in list SUBS1 for the first message and in list SUBS2 for the second message. Each element of SUBS1 and SUBS2 contains the two options (e.g., "as well" and "too" or "USD" and "$") and a string "_i_" that refers to the place in the messages where these options would fit.

The function get_variant(template, subs, index) returns a variant indexed by variable index. Then we iterate this index over the numbers from 0 to 2^16 - 1, and compute all variants of the first message and store their trhash values in list H. After that, we iterate the index again over the range 0 ... 2^16 - 1, and compute variants of the second message, hash them, and check if the hash values appear already in list H. If so, we found a match, we determine which variant of the first message produced the matching hash value in H, and we output the two message variants that have the same hash.

We get this result:

$ python3 birthday_attack.py 
Half-way done.
Dear Mr.Jones! I regret to inform you that your complaint wasn't approved  by the management. This, unfortunately means that you can't reclaim your cost of 1 234 USD and in addition, you have to cover our investigation cost of 345 $ too. Yours sincerely, Andrew B. Clark
21c20666
Dear Mr.Jones, I am delighted to inform you, that you have been selected as one of our winners of our competion.  Your prize will be 1,000,000 $, which we will transfer to your bank account within one week. Best regards, A. B. Clark
21c20666
All done.

