4-squares cipher
================

From the given plaintext fragment "filesareopened", we can recover the following mappings:

    fi --» CB
    le --» JP
    sa --» KE
    re --» SP
    op --» EU
    en --» HL
    ed --» HA

This gives the following partial squares:

    a b c d e   - - - H -
    f g h i j   - - - C -
    k l m n o   E - - - J
    p r s t u   K - - - S
    v w x y z   - - - - -

    - P E - A   a b c d e
    B - - - -   f g h i j
    - - - - L   k l m n o
    - - - - U   p r s t u
    - - - - -   v w x y z

We can continue with the other plaintext fragments given in the same way. We must be careful in identifying the right 2-gram boundaries, though. For instance, the plaintext word 'encoded' does not start at a 2-gram boundary, so we can only use the letter pairs nc, od, and ed from it (moreover, ed has already be mapped). This gives the following mappings and partial squares:

    nc --» GN
    od --» IA
    ea --» PA
    da --» PN
    nd --» IN
    wr --» VR
    it --» CT
    te --» SN
    on --» IL
    ta --» KN
    in --» CK

    a b c d e   P - - H -
    f g h i j   - - - C -
    k l m n o   E - G I J
    p r s t u   K - - - S
    v w x y z   - V - - -

    - P E N A   a b c d e
    B - - - -   f g h i j
    - - - K L   k l m n o
    - R - T U   p r s t u
    - - - - -   v w x y z


We continue with guessing the bottom left square. For instance, knowing that after the keyword the remaining letters of the alphabet are ordered, we can see that:
- the last row can only be V, W, X, Y, Z, 
- between B and K all letters should occur except E which has already been used earlier in the square, 
- between R and T only S could be missing.

    a b c d e   P - - H -
    f g h i j   - - - C -
    k l m n o   E - G I J
    p r s t u   K - - - S
    v w x y z   - V - - -

    - P E N A   a b c d e
    B C D F G   f g h i j
    H I J K L   k l m n o
    - R S T U   p r s t u
    V W X Y Z   v w x y z

Now, the keyword at the beginning can be either OPEN or MPEN. The first is more likely, so we get

    a b c d e   P - - H -
    f g h i j   - - - C -
    k l m n o   E - G I J
    p r s t u   K - - - S
    v w x y z   - V - - -

    O P E N A   a b c d e
    B C D F G   f g h i j
    H I J K L   k l m n o
    M R S T U   p r s t u
    V W X Y Z   v w x y z


Next, we try to guess the upper right square using the following observations:
- between C and E only D could be missing
- between E and G only F could be missing

    a b c d e   P - - H -
    f g h i j   - - - C D
    k l m n o   E F G I J
    p r s t u   K - - - S
    v w x y z   - V - - -

    O P E N A   a b c d e
    B C D F G   f g h i j
    H I J K L   k l m n o
    M R S T U   p r s t u
    V W X Y Z   v w x y z


Now, let's try to decrypt the ciphertext with what we have:

    JK MI YH IW CB JP KE SP EU HL HA CK SN XS JJ ON
    MF HM JE HH RX JU SP HO HH YY RC SN RS RC FF KD
    SI EE IN SK MF PG AK YZ CD TD YM OA GN IA HA CK
    TM SO HD CB OE GN IA CK CC DO GN IA CK CC RJ IU
    KS TA NF DN HT DE ON NO LL RF KS EP KF FU IE PU
    HL ON IT SE OL SO FN PM SO IN HA SK MF TL IA OL
    SO GT MF PG AK HG FN CK YM WK IA HL FZ MF HA HM
    HB LS PA PN IN VR CT SN IF IT DE DH MI EG HW SN
    SJ OC TA MT MF BT JJ ON MD JU IP OP MU HA DH KP
    FI CB JP RS NE RN IL MN IL KN CK SN XS

    no .. .. ly fi le sa re op en ed in te .. mo ..
    .. at me an .. ou re ad an .. .. te .. .. ng sf
    ro ma nd to .. ef .. .. .. .. .. .e nc od ed in
    .. pe ci fi .. nc od in gi .. nc od in gi .. ot
    sp .. .. ie dt he .. .. .. .. sp la tf or md ep
    en .. nt se .. pe nb ap pe nd ed to .. .. od ..
    pe ns .. ef .. ei nb in .. .. od en .. .. ed at
    ai .r ea da nd wr it te n. nt he fo .. of by te
    so .. .. .. .. .. mo .. .. ou ld .. .. ed fo ra
    ll fi le .. .. .. on .c on ta in te ..


We continue by guessing some missing plaintext:

- "in .. pe ci fi .. nc od in g" could be "in as pe ci fi ce nc od in g", which means

    as --» TM
    ce --» OE

- "sp .. .. ie d" could be "sp ec if ie d", which means that 

    ec --» TA
    if --» NF

- "p la tf or md ep en .. nt" could be "p la tf or md ep en de nt", which means 

    de --» ON

- "fo .. of by te" could be "fo rm of by te", which means 

    rm --» MI

With this, the matrices become:

    a b c d e   P - T H O
    f g h i j   N - - C D
    k l m n o   E F G I J
    p r s t u   K - M - S
    v w x y z   - V - - -

    O P E N A   a b c d e
    B C D F G   f g h i j
    H I J K L   k l m n o
    M R S T U   p r s t u
    V W X Y Z   v w x y z

and the text becomes:

    no rm .. ly fi le sa re op en ed in te .. mo de
    .. at me an .. ou re ad an .. .. te .. .. ng sf
    ro ma nd to .. ef .. .. .. .. .. .e nc od ed in
    as pe ci fi ce nc od in gi .. nc od in gi .. ot
    sp ec if ie dt he de .. .. .. sp la tf or md ep
    en de nt se .. pe nb ap pe nd ed to .. .. od ..
    pe ns .. ef .. ei nb in .. .. od en .. .. ed at
    ai .r ea da nd wr it te n. nt he fo rm of by te
    so .. ec .. .. .. mo de .. ou ld .. .. ed fo ra
    ll fi le .. .. .. on .c on ta in te ..


Finally, we can guess the upper right square as follows:
- the keyword may be PYTHON
- then A and B should follow
- K must be followd by L
- M must be followed by R
- and the last row can only be U, V, W, X, Z

    a b c d e   P Y T H O
    f g h i j   N A B C D
    k l m n o   E F G I J
    p r s t u   K L M R S
    v w x y z   U V W X Z

    O P E N A   a b c d e
    B C D F G   f g h i j
    H I J K L   k l m n o
    M R S T U   p r s t u
    V W X Y Z   v w x y z

and the text becomes:

    no rm al ly fi le sa re op en ed in te xt mo de
    th at me an sy ou re ad an dw ri te st ri ng sf
    ro ma nd to th ef il ew hi ch ar ee nc od ed in
    as pe ci fi ce nc od in gi fe nc od in gi sn ot
    sp ec if ie dt he de fa ul ti sp la tf or md ep
    en de nt se eo pe nb ap pe nd ed to th em od eo
    pe ns th ef il ei nb in ar ym od en ow th ed at
    ai sr ea da nd wr it te ni nt he fo rm of by te
    so bj ec ts th is mo de sh ou ld be us ed fo ra
    ll fi le st ha td on tc on ta in te xt

or

    normally files are opened in text mode
    that means you read and write strings f-
    rom and to the file which are encoded in
    a specific encoding if encoding is not
    specified the default is platform dep-
    endent see open b appended to the mode o-
    pens the file in binary mode now the dat-
    a is read and written in the form of byte
    s objects this mode should be used for a-
    ll files that dont contain text
