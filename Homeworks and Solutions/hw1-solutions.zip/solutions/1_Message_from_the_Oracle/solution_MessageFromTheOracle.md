A message from the Oracle
=========================

Ahura Mazda is the creator and sole God of Zoroastrianism, the old Mede and Persian religion, which spread across Asia predating Christianity. The oracle may refer to the Oracle at Delphi. So the message may be a Spartan message intercepted by the men of Xerxes, and it may be encrypted with the Scytale. 

The Scytale is a transposition cipher, which mixes the letters of the plaintext message. The ciphertext can be decrypted by finding the period length L such that rearranging the letters by taking every L-th letter results in a meaningful text.

By trying out different period lengths L, and rearranging the letters by taking every L-th letter, one can soon recover the following meaningful text for L = 7:

For you inhabitants of wide 
wayed Sparta Either your gre
at and glorious city must be
 wasted by Persian men Or if
 not that then the bound of 
Lacedaemon must mourn a dead
 king from Heracles line

This is the beginning of the prophecy of the Oracle at Delphi made before the Battle of Thermopylae.