import md5x3
import time

X  = b'*THIS_IS_A_TEST_INPUT_FOR_MD5X3*'
XL = b'*THIS_IS_A_TEST_'
XR = b'INPUT_FOR_MD5X3*'
Y  = bytes.fromhex('f1eba0e1e77269c82f29b7a695dc7ae4899991ebcbeafe1c6a5fdb873621f750')
YL = bytes.fromhex('f1eba0e1e77269c82f29b7a695dc7ae4')
YR = bytes.fromhex('899991ebcbeafe1c6a5fdb873621f750')

M = []
start_time = time.time()
for i in range(2**16):
    k0 = i.to_bytes(2, byteorder='big')
    print(k0.hex(), end='\r')
    m, n = md5x3.RF(XL, XR, k0)
    M.append(m)
lap_time = time.time()
print('One third done in '+ str(round(lap_time-start_time)) + ' seconds.')

for i in range(2**16):
    k2 = i.to_bytes(2, byteorder='big')
    print(k2.hex(), end='\r')
    m, n = md5x3.RF(YL, YR, k2)
    if m in M:
        k0 = M.index(m).to_bytes(2, byteorder='big')
        break
lap_time = time.time()
print('Two thirds done in '+ str(round(lap_time-start_time)) + ' seconds.')

for i in range(2**16):
    k1 = i.to_bytes(2, byteorder='big')
    print(k0.hex()+k1.hex()+k2.hex(), end='\r')
    K = k0 + k1 + k2
    if md5x3.ENC(X, K) == Y: break
stop_time = time.time()
print('All done in ' + str(round(stop_time-start_time)) + ' seconds.')
print('Recovered key: ' + K.hex())
