Hints for this challenge are provided in the file `PO_attack_skeleton.py` in the form of comments.

